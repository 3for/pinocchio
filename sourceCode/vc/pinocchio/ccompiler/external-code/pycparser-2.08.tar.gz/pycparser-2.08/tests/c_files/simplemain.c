#include "hdir\emptydir\..\9\inc.h"

int main() {
  return 0;
}
