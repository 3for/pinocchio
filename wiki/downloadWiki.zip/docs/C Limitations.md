1. Some operators are not usable: ++, >>=
2. No typedef
3. No empty statements {} or ;
4. Nested scope operators are parsed incorrectly:

{{
    for (k = 0; k < 10; k+=1) {
        for (j = 0; j < 5; j+=1) {
             u32 k = input[j](j);   // This definition of k will conflicts with the k in the outer scope above 
             output[j](j) += k;
        }
    } 
}}
      