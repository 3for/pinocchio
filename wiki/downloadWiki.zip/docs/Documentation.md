## Resources
The following pages or external links may be helpful to anyone starting to use Pinocchio.
* [UMD Notes](UMD-Notes): notes on getting started, compiled from several students at University of Maryland cybersecurity research lab
* [NIZK or zkSNARK](NIZK-or-zkSNARK): how to use zero-knowledge, prover-only inputs
* [C Limitations](C-Limitations): a list of some of the restrictions on C input, and possible explanations of errors 

