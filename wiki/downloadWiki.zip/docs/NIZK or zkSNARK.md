It's possible (in recent versions of Pinocchio) to indicate that some of the prover's inputs should be "hidden" from the verifier. 

1. Your program needs to take a third NIZK struct (in addition to the usual input/output structs). The compiler will turn those into prover-only values. This results in an arithmetic circuit file where some of the input wires are labeled "nizkinput" rather than just "input". 

2. You need to use the -nizk flag on the qapv2.exe commandline.

There is an example called "nizk-test.c" demonstrating how to do this in code.